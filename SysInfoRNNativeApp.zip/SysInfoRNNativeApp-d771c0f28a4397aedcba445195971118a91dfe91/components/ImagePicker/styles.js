import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  box: {
    padding: 10,
  },
});

export default styles;
