import React from 'react';
import {View, Text} from 'react-native';

const ChangePassword = () => {
  return (
    <View>
      <Text>Change Password</Text>
    </View>
  );
};

export default ChangePassword;
